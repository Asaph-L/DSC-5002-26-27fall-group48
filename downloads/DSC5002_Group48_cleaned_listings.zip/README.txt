DSC5002 Group 48 — Cleaned Craigslist listings
================================================

This is the early cleaning output from notebooks/02_clean_and_derive.ipynb
for the Kaggle v10 snapshot. It contains 393,985 positive-price listings
and 18 columns. Price is the advertised asking price in USD. Odometer
is in miles, and vehicle_age is listing_year minus model_year.

Extract listings.csv into data/processed/ under the repository root.
The three *_review flags mark observations to inspect. These rows remain
in this cleaned file. Missing values are empty CSV cells. The ZIP does
not include the raw dataset or the later research/model caches. Some
notebooks still require the original vehicles.csv.

This project download contains the structured, cleaned subset. Cite
the Kaggle v10 snapshot and this project's cleaning notebook when
using the data.

下载使用说明
------------
本压缩包是项目早期清洗 notebook 的原样输出，含 393,985 条正价格挂牌和
18 列。价格为挂牌价（美元），里程以英里计。将 listings.csv 解压到项目
目录下的 data/processed/。三个复核标记用于识别需要检查的记录，这些记录
仍保留在清洗表中。部分 notebooks 仍需 Kaggle 原始 vehicles.csv。
使用本数据时，请注明 Kaggle v10 快照及本项目的清洗 notebook。

Source and reproducibility
--------------------------
Kaggle v10:
https://www.kaggle.com/datasets/austinreese/craigslist-carstrucks-data/versions/10
Project:
https://github.com/Asaph-L/DSC-5002-26-27fall-group48
SHA-256 (listings.csv):
e065867e768c12e217d9b9f8ee1c0e0eaae12575fa45a4b32a3ebb96f58e0dbd
